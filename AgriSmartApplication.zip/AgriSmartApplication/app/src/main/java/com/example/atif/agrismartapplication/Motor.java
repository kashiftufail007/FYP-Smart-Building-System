package com.example.atif.agrismartapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Motor extends AppCompatActivity {
    private ToggleButton motorButton;
    private Switch switchEnableButton;

    /*private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference databaseReference;
    private FirebaseUser user;

    private String userID;*/

    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motor);

        /*firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Users");
        user = firebaseAuth.getCurrentUser();
        userID = user.getUid();*/

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Motor");

        motorButton = (ToggleButton) findViewById(R.id.motor_custom_button);
        switchEnableButton = (Switch) findViewById(R.id.motor_switch);

        databaseReference = FirebaseDatabase.getInstance().getReference();

        motorButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    databaseReference.child("MOTOR_STATUS").setValue("ON");
                    Toast.makeText(Motor.this, "Motor is ON", Toast.LENGTH_LONG).show();



                    /*Field field = new Field();

                    databaseReference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                                Field field = new Field();

                                FirebaseDatabase.getInstance().getReference("Users")
                                        .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                        .setValue(field).addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful()) {
                                            Toast.makeText(Motor.this, "ON", Toast.LENGTH_LONG).show();
                                        }

                                    }
                                });
                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(Motor.this, databaseError.getMessage(), Toast.LENGTH_LONG).show();

                        }
                    });*/

                    //Toast.makeText(Motor.this, "Motor is ON", Toast.LENGTH_LONG).show();


                }else {
                    databaseReference.child("MOTOR_STATUS").setValue("OFF");
                    Toast.makeText(Motor.this, "Motor is OFF", Toast.LENGTH_LONG).show();
                }
            }
        });

        /*motorButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Motor.this, "Motor is ON", Toast.LENGTH_LONG).show();
            }
        });*/

        switchEnableButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    motorButton.setEnabled(true);
                }else {
                    motorButton.setEnabled(false);
                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
