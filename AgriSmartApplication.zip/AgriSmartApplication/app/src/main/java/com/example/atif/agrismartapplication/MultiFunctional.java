package com.example.atif.agrismartapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import static android.content.ContentValues.TAG;

public class MultiFunctional extends AppCompatActivity {

    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference databaseReference;
    private FirebaseUser user;

    private String userID;
    private TextView tvWaterLevel;

    private TextView tvTemp;
    private TextView tvHumidity;
    private TextView tvMoisture;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multifunctional);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Multifunctional");

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();

        tvTemp = (TextView) findViewById(R.id.tv_temp);
        tvHumidity = (TextView) findViewById(R.id.tv_humidity);
        tvMoisture = (TextView) findViewById(R.id.tv_moisture);

        Query lastQuery_temperature = databaseReference.child("Sensor/Tempratue").orderByKey().limitToLast(1);
        lastQuery_temperature.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.exists()) {
                    for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String temperature = userSnapshot.getValue().toString();
                        Log.d(TAG, "showData: temperature" +temperature);
                        tvTemp.setText(temperature);



                        /*Field field = new Field();
                        field.setTemperature(userSnapshot.child("").getValue(Field.class).getTemperature());
                        Log.d(TAG, "showData: temperature: " + field.getTemperature());
                        tvTemp.setText(field.getTemperature());*/

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Query lastQuery_humidity = databaseReference.child("Sensor/Humidity").orderByKey().limitToLast(1);

        lastQuery_humidity.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    for(DataSnapshot userSnapshot : dataSnapshot.getChildren())
                    {
                        String humidity = userSnapshot.getValue().toString();
                        tvHumidity.setText(humidity);

                        /*Field field = new Field();

                        field.setHumidity(userSnapshot.getValue(Field.class).getHumidity());
                        Log.d(TAG, "showData: humidity: " + field.getHumidity());

                        tvHumidity.setText(field.getHumidity());*/

                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Query queryLast_moisture = databaseReference.child("Sensor/Moisture").orderByKey().limitToLast(1);

        queryLast_moisture.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                        String moisture = userSnapshot.getValue().toString();
                        tvMoisture.setText(moisture);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        user = firebaseAuth.getCurrentUser();
        userID = user.getUid();
        //tvWaterLevel = (TextView) findViewById(R.id.tv_water_level);

    }

    /*@Override
    protected void onStart() {
        super.onStart();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    Field field = new Field();

                    field.setWater_level(userSnapshot.child(userID).getValue(Field.class).getWater_level());
                    Log.d(TAG, "showData: waterLevel: " + field.getWater_level());

                    tvWaterLevel.setText(field.getWater_level());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_LONG).show();

            }
        });
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
