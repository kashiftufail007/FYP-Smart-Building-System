package com.example.atif.agrismartapplication;

public class Field {

    public String temperature, humidity, moisture, water_level, motor;

    public Field() {

    }

    public Field(String temperature, String humidity, String moisture, String water_level, String motor) {
        this.temperature = temperature;
        this.humidity = humidity;
        this.moisture = moisture;
        this.water_level = water_level;
        this.motor = motor;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getMoisture() {
        return moisture;
    }

    public void setMoisture(String moisture) {
        this.moisture = moisture;
    }

    public String getWater_level() {
        return water_level;
    }

    public void setWater_level(String water_level) {
        this.water_level = water_level;
    }

    public String getMotor() {
        return motor;
    }

    public void setMotor(String motor) {
        this.motor = motor;
    }
}
