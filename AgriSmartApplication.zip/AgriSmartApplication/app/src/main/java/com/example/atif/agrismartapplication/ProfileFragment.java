package com.example.atif.agrismartapplication;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class ProfileFragment extends Fragment {

    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference databaseReference;
    private FirebaseUser user;

    private String userID;
    private ListView listViewUser;

    private TextView tvEmailVerfiy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        getActivity().setTitle("Profile");
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        SetupUI(view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                // To display results of all users.
                //userList.clear();

                /*for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    User user = userSnapshot.getValue(User.class);
                    userList.add(user);
                }

                ProfileList adapter = new ProfileList(getActivity(), userList);
                listViewUser.setAdapter(adapter);*/

                for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    User user = new User();

                    user.setName(dataSnapshot.child(userID).getValue(User.class).getName());
                    user.setEmail(dataSnapshot.child(userID).getValue(User.class).getEmail());
                    user.setPhone(dataSnapshot.child(userID).getValue(User.class).getPhone());

                    Log.d(TAG, "showData: name: " + user.getName());
                    Log.d(TAG, "showData: email: " + user.getEmail());
                    Log.d(TAG, "showData: phone: " + user.getPhone());

                   /* ArrayList<String> array = new ArrayList<>();
                    array.add(user.getName());
                    array.add(user.getEmail());
                    array.add(user.getPhone());*/

                    String [] titleArr = {"Name", "Email", "Phone"};
                    String [] descArr = {user.getName(), user.getEmail(), user.getPhone()};

                    ArrayList<Map<String, Object>> itemDataList = new ArrayList<Map<String, Object>>();
                    int titleLen = titleArr.length;
                    for(int i=0; i<titleLen; i++) {
                        Map<String, Object> listItemMap = new HashMap<String, Object>();
                        listItemMap.put("title", titleArr[i]);
                        listItemMap.put("description", descArr[i]);
                        itemDataList.add(listItemMap);
                    }

                    try {
                        /*ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, array);
                        listViewUser.setAdapter(adapter);*/

                        SimpleAdapter simpleAdapter = new SimpleAdapter(getActivity(), itemDataList , android.R.layout.simple_list_item_2,
                                new String[] {"title", "description"}, new int[] {android.R.id.text1, android.R.id.text2});
                        listViewUser.setAdapter(simpleAdapter);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }

    private void emailVerification() {
        firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser user = firebaseAuth.getCurrentUser();

        if(user.isEmailVerified()) {
            tvEmailVerfiy.setText("Verified.");
        }
        else {
            tvEmailVerfiy.setText("Not Verified (Click to verify).");
            tvEmailVerfiy.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getActivity(), "Verification Email Sent", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
    }

    private void SetupUI(View view) {
        listViewUser = view.findViewById(R.id.listViewUser);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Users");
        //databaseReference = FirebaseDatabase.getInstance().getReference("Users");
        user = firebaseAuth.getCurrentUser();
        userID = user.getUid();

        tvEmailVerfiy = view.findViewById(R.id.tv_email_verify);
        emailVerification();
    }
}
