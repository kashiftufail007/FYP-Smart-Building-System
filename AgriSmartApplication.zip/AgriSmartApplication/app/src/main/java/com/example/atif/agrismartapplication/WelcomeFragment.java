package com.example.atif.agrismartapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.content.ContentValues.TAG;

import java.util.ArrayList;
import java.util.List;

public class WelcomeFragment extends Fragment implements View.OnClickListener {

    private TextView tvUserEmail;
    //private TextView name, phone;
    private ListView listViewUser;
    private TextView tvEmailVerification;
    private Button btnLogout;

    private FirebaseDatabase firebaseDatabase;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference databaseReference;
    private FirebaseUser user;
    private String userID;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_welcome, container, false);
        super.onCreateView(inflater, container, savedInstanceState);
        View view = inflater.inflate(R.layout.fragment_welcome, container, false);
        SetupUI(view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        firebaseAuth = FirebaseAuth.getInstance();
        if(firebaseAuth.getCurrentUser() == null) {
            getActivity().finish();
            startActivity(new Intent(getActivity(), LoginActivity.class));
        }

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                    User user_1 = new User();

                    user_1.setName(dataSnapshot.child(userID).getValue(User.class).getName());
                    Log.d(TAG,"showData: name: " +user_1.getName());

                    tvUserEmail.setText("Hi, " + user_1.getName());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(), databaseError.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void emailVerification() {
        firebaseAuth = FirebaseAuth.getInstance();
        final FirebaseUser user = firebaseAuth.getCurrentUser();

        if(user.isEmailVerified()) {
            tvEmailVerification.setText("Verified.");
        }
        else {
            tvEmailVerification.setText("Not Verified (Click to verify).");
            tvEmailVerification.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            Toast.makeText(getActivity(), "Verification Email Sent", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });
        }
    }

    private void SetupUI(View view) {

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Users");
        user = firebaseAuth.getCurrentUser();
        userID = user.getUid();

        if(user == null) {
            getActivity().finish();
            startActivity(new Intent(getActivity(), LoginActivity.class));
        }

        tvUserEmail = view.findViewById(R.id.tv_email);
        //tvUserEmail.setText("Welcome " +user.getEmail());
        tvEmailVerification = view.findViewById(R.id.tv_email_verification);

        //btnLogout = view.findViewById(R.id.btn_Logout);

        emailVerification();

        //btnLogout.setOnClickListener((View.OnClickListener) this);
    }

    @Override
    public void onClick(View v) {
       /* if(v == btnLogout) {
            firebaseAuth.signOut();
            getActivity().finish();
            startActivity(new Intent(getActivity(), LoginActivity.class));
        }*/
    }
}