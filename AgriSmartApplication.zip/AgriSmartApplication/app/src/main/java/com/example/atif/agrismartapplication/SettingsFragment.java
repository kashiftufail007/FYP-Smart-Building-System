package com.example.atif.agrismartapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class SettingsFragment extends Fragment {

    //private Button btnChangePassword;
    private TextView tvChangePassword;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return inflater.inflate(R.layout.fragment_settings, container, false);

        super.onCreateView(inflater, container, savedInstanceState);
        getActivity().setTitle("Settings");
        View view = inflater.inflate(R.layout.fragment_settings, container, false);
        SetupUI(view);
        return view;
    }

    private void SetupUI(View view) {
        tvChangePassword = view.findViewById(R.id.tv_change_password);
        tvChangePassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getActivity(), ChangePassword.class);
                startActivity(i);
            }
        });

    }

}
