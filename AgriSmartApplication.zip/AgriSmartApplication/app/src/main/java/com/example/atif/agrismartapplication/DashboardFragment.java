package com.example.atif.agrismartapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.cardview.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class DashboardFragment extends Fragment implements View.OnClickListener {

    CardView tempCard, humidityCard, moistureCard, waterLevelCard, motorCard;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        getActivity().setTitle("Dashboard");
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        setupUI(view);
        return view;
    }

    private void setupUI(View view) {
        //Defining Cards
        tempCard = view.findViewById(R.id.temp_card);
        humidityCard = view.findViewById(R.id.humidity_card);
        moistureCard = view.findViewById(R.id.moisture_card);
        waterLevelCard = view.findViewById(R.id.water_level_card);
        motorCard = view.findViewById(R.id.motor_card);

        //Add click listener to the cards
        tempCard.setOnClickListener((View.OnClickListener) this);
        humidityCard.setOnClickListener((View.OnClickListener) this);
        moistureCard.setOnClickListener((View.OnClickListener) this);
        waterLevelCard.setOnClickListener((View.OnClickListener) this);
        motorCard.setOnClickListener((View.OnClickListener) this);
    }


    @Override
    public void onClick(View v) {
        Intent i;

        switch (v.getId()) {
            case R.id.temp_card:
                i = new Intent(getActivity(), Temperature.class);
                startActivity(i);
                break;

            case R.id.humidity_card:
                i = new Intent(getActivity(), Humidity.class);
                startActivity(i);
                break;

            case R.id.moisture_card:
                i = new Intent(getActivity(), Moisture.class);
                startActivity(i);
                break;
            case R.id.water_level_card:
                i = new Intent(getActivity(), MultiFunctional.class);
                startActivity(i);
                break;

            case R.id.motor_card:
                i = new Intent(getActivity(), Motor.class);
                startActivity(i);
                break;

            default: break;
        }
    }
}
